import React, { useState } from "react";
import Search from "./components/Search";
import Results from "./components/Results";
import "./App.css";

const App = () => {
  const [results, setResults] = useState([]);
  const [favourites, setFavourites] = useState([]);

  const addFavourite = (item) => {
    setFavourites([...favourites, item]);
  };

  const removeFavourite = (id) => {
    setFavourites(favourites.filter((fav) => fav.trackId !== id));
  };

  return (
    <div className="App">
      <h1>iTunes Search</h1>
      <Search setResults={setResults} />
      <Results
        results={results}
        addFavourite={addFavourite}
        removeFavourite={removeFavourite}
        favourites={favourites}
      />
    </div>
  );
};

export default App;
