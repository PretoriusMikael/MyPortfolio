import React, { useState } from "react";
import axios from "axios";
import "../styling/Search.css";

const Search = ({ setResults }) => {
  const [query, setQuery] = useState("");
  const [mediaType, setMediaType] = useState("all");

  const handleSearch = async () => {
    try {
      const response = await axios.get(`http://localhost:5000/api/search`, {
        params: {
          term: query,
          media: mediaType,
        },
      });
      setResults(response.data.results);
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div>
      <input
        type="text"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Search term"
      />
      <select onChange={(e) => setMediaType(e.target.value)} value={mediaType}>
        <option value="all">All</option>
        <option value="movie">Movies</option>
        <option value="podcast">Podcasts</option>
        <option value="music">Music</option>
        <option value="audiobook">Audiobooks</option>
        <option value="shortFilm">Short Films</option>
        <option value="tvShow">TV Shows</option>
        <option value="software">Software</option>
        <option value="ebook">Ebooks</option>
      </select>
      <button onClick={handleSearch}>Search</button>
    </div>
  );
};

export default Search;
