import React from "react";
import "../styling/Results.css";

const Results = ({ results, addFavourite, removeFavourite, favourites }) => {
  return (
    <div>
      <h2>Results</h2>
      <ul className="Results">
        {results.map((item) => (
          <li key={item.trackId}>
            <img src={item.artworkUrl100} alt={item.trackName} />
            <div>Track name: {item.trackName}</div>
            <div>Artist: {item.artistName}</div>
            <div>
              Release Date: {new Date(item.releaseDate).toLocaleDateString()}
            </div>
            <div>
              Price: {item.trackPrice} {item.currency}
            </div>
            <a href={item.trackViewUrl} className="View" target="_blank">
              View
            </a>
            {item.previewUrl && (
              <div>
                <span className="divider"> / </span>
                <a
                  href={item.previewUrl}
                  className="View"
                  target="_blank"
                  rel="noopener noreferrer">
                  Listen
                </a>
              </div>
            )}
            <div className="actions">
              <button onClick={() => addFavourite(item)}>
                Add to Favourites
              </button>
            </div>
          </li>
        ))}
      </ul>
      {favourites.length > 0 && (
        <>
          <h2>Favourites</h2>
          <ul className="Favourites">
            {favourites.map((item) => (
              <li key={item.trackId}>
                <img src={item.artworkUrl100} alt={item.trackName} />
                <div>{item.trackName}</div>
                <div>Artist: {item.artistName}</div>
                <div>
                  Release Date:{" "}
                  {new Date(item.releaseDate).toLocaleDateString()}
                </div>
                <div className="actions">
                  <button onClick={() => removeFavourite(item.trackId)}>
                    Remove from Favourites
                  </button>
                </div>
              </li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
};

export default Results;
