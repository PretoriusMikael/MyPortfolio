# iTunes Search App

A full-stack application built with React and Express that interfaces with the iTunes Search API.

## Frontend

This project was bootstrapped with Create React App.

### Available Scripts

In the frontend directory, you can run:

#### `npm start`

Runs the app in the development mode. Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

### Instructions

- Run the backend server first.
- Then run the frontend app.

## Backend

This server uses Express and communicates with the iTunes Search API.

### Environment Variables

Create a `.env` file in the backend directory and add your JWT secret key:

```plaintext
JWT_SECRET=your_jwt_secret_key
```
